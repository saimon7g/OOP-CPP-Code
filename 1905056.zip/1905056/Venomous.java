interface Venomous {
    boolean isLethalToAdultHumans();
}